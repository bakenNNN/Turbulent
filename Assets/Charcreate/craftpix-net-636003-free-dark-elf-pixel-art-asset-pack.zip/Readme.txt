Font that was used for this content: 
https://www.dafont.com/digital-disco.font
Texture that was used for the background of the preview:
https://texturehaven.com/tex/?t=castle_brick_02_red